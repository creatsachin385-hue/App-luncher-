package com.samsung.taba7lite.edgelauncher.ui

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.PowerManager
import android.provider.Settings
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.samsung.taba7lite.edgelauncher.databinding.ActivityMainBinding
import com.samsung.taba7lite.edgelauncher.service.EdgeOverlayService

/**
 * MainActivity
 * 
 * Clean onboarding flow tailored for Samsung Galaxy Tab A7 Lite (One UI Core):
 * 1. Checks Settings.canDrawOverlays(this)
 * 2. Guides user to disable Samsung "Deep Sleeping Apps" battery optimization
 * 3. Starts and stops EdgeOverlayService
 */
class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setupListeners()
    }

    override fun onResume() {
        super.onResume()
        updatePermissionStatus()
    }

    private fun setupListeners() {
        binding.btnGrantOverlay.setOnClickListener {
            if (!Settings.canDrawOverlays(this)) {
                val intent = Intent(
                    Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:$packageName")
                )
                startActivity(intent)
            } else {
                Toast.makeText(this, "Overlay permission already granted", Toast.LENGTH_SHORT).show()
            }
        }

        binding.btnWhitelistBattery.setOnClickListener {
            val powerManager = getSystemService(Context.POWER_SERVICE) as PowerManager
            if (!powerManager.isIgnoringBatteryOptimizations(packageName)) {
                val intent = Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS).apply {
                    data = Uri.parse("package:$packageName")
                }
                startActivity(intent)
            } else {
                Toast.makeText(this, "Battery optimization already ignored", Toast.LENGTH_SHORT).show()
            }
        }

        binding.switchService.setOnCheckedChangeListener { _, isChecked ->
            if (isChecked) {
                if (!Settings.canDrawOverlays(this)) {
                    Toast.makeText(this, "Please grant Overlay permission first", Toast.LENGTH_LONG).show()
                    binding.switchService.isChecked = false
                    return@setOnCheckedChangeListener
                }
                startOverlayService()
            } else {
                stopOverlayService()
            }
        }
    }

    private fun updatePermissionStatus() {
        val hasOverlay = Settings.canDrawOverlays(this)
        val powerManager = getSystemService(Context.POWER_SERVICE) as PowerManager
        val isBatteryIgnored = powerManager.isIgnoringBatteryOptimizations(packageName)

        binding.tvOverlayStatus.text = if (hasOverlay) "Granted" else "Required"
        binding.tvBatteryStatus.text = if (isBatteryIgnored) "Whitelisted" else "Optimization active"

        binding.btnGrantOverlay.isEnabled = !hasOverlay
        binding.btnWhitelistBattery.isEnabled = !isBatteryIgnored
    }

    private fun startOverlayService() {
        val serviceIntent = Intent(this, EdgeOverlayService::class.java)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            startForegroundService(serviceIntent)
        } else {
            startService(serviceIntent)
        }
    }

    private fun stopOverlayService() {
        val serviceIntent = Intent(this, EdgeOverlayService::class.java)
        stopService(serviceIntent)
    }
}
